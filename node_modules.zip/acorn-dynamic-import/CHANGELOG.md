# 3.0.0

- Adding acorn walk support.
- Bump acorn version.

# 2.0.2

- Fixing parsing of `yield import()`.

# 2.0.1

- Removing unnecessary `in-publish` dependency.

# 2.0.0

- Updating acorn version to >= 4.

# 1.0.1

- Fixes for publishing the module.

# 1.0.0

- Initial release of plugin.
