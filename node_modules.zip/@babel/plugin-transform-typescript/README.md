# @babel/plugin-transform-typescript

> Transform TypeScript into ES.next

See our website [@babel/plugin-transform-typescript](https://babeljs.io/docs/en/next/babel-plugin-transform-typescript.html) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-transform-typescript
```

or using yarn:

```sh
yarn add @babel/plugin-transform-typescript --dev
```
